IEEE Access-style manuscript: CAFN (cross-attention fusion of 3D sMRI + 1D VEP)
================================================================================
Build:   pdflatex main.tex   (run twice; no BibTeX needed - bibliography is in refs.tex)
Files:   main.tex            manuscript body (sections I-VII, figures, tables)
         ieeeaccessapprox.cls  LOCAL APPROXIMATION of the IEEE Access layout
         refs.tex            hand-written IEEE-style bibliography (34 entries, citation order)
         numbers.tex, tab_*.tex  numbers/tables generated from the recorded measurements
         figs/               figures used in the paper

IMPORTANT
- The official ieeeaccess.cls / IEEEtran.bst could not be downloaded in the build
  environment, so ieeeaccessapprox.cls reproduces the look (two-column, 10 pt,
  sans-serif headings, running header/footer) using the official macro names
  (\history, \doi, \tfootnote, \corresp, \markboth, \address, \PARstart, \EOD,
  abstract/keywords environments). To submit: download the official template from
  https://ieeeaccess.ieee.org/ and paste the body of main.tex into it, replacing
  \documentclass{ieeeaccessapprox} with \documentclass{ieeeaccess}.
- Yellow boxes are placeholders to fill in: author e-mail, funding statement,
  acknowledgement (guide name), biography. DOI and dates are IEEE placeholders.
- No model training or tests were run for this paper (PyTorch was not available);
  all numbers are the recorded measurements on synthetic data. No accuracy is claimed.
- References were written from known publication details - spot-check volume/page/DOI.
